from django.apps import AppConfig


class TourplanningConfig(AppConfig):
    name = 'tourplanning'
